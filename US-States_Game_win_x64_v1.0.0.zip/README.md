# US States Game
# Written by Kyle Pummell

This build is version 1.0.0 and targets Windows 11+ x64 bit<br />
background image and state data file provided by LondonAppBrewery @ Udemy.com

To launch, double-click or right-click and select 'open' to open the 'main.exe' file.
